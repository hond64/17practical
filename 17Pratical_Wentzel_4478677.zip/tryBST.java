//Miguel Wentzel
//4478677
//Practical 7

import java.util.*;

class Node {
    int data;
    Node left, right;

    public Node(int item) {
        data = item;
        left = right = null;
    }
}

class BST {
    Node root;

    public Node insert(Node root, int data) {
        if (root == null) {
            return new Node(data);
        }

        if (data < root.data) {
            root.left = insert(root.left, data);
        } else if (data > root.data) {
            root.right = insert(root.right, data);
        }

        return root;
    }

    // Build balanced BST from sorted array
    public void buildBalanced(int[] arr, int start, int end) {
        if (start > end) return;

        int mid = start + (end - start) / 2;
        root = insert(root, arr[mid]);

        buildBalanced(arr, start, mid - 1);
        buildBalanced(arr, mid + 1, end);
    }

    // Check if tree is BST
    public boolean isBST() {
        return isBSTUtil(root, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    private boolean isBSTUtil(Node node, int min, int max) {
        if (node == null) return true;

        if (node.data <= min || node.data >= max) return false;

        return isBSTUtil(node.left, min, node.data) &&
               isBSTUtil(node.right, node.data, max);
    }

    // Delete node
    public Node delete(Node root, int key) {
        if (root == null) return root;

        if (key < root.data) {
            root.left = delete(root.left, key);
        } else if (key > root.data) {
            root.right = delete(root.right, key);
        } else {
            // Node with one child or no child
            if (root.left == null) return root.right;
            else if (root.right == null) return root.left;

            // Node with two children
            root.data = minValue(root.right);
            root.right = delete(root.right, root.data);
        }

        return root;
    }

    private int minValue(Node root) {
        int minv = root.data;
        while (root.left != null) {
            minv = root.left.data;
            root = root.left;
        }
        return minv;
    }

    // Remove even numbers (efficient traversal)
    public void removeEvens(Node node) {
        if (node == null) return;

        removeEvens(node.left);
        removeEvens(node.right);

        if (node.data % 2 == 0) {
            root = delete(root, node.data);
        }
    }
}

public class tryBST {

    public static void main(String[] args) {
        int n = 15;
        int max = (int) Math.pow(2, n) - 1;
        int runs = 30;

        long totalTime = 0;
        long totalTimeDelete = 0;

        long[] times = new long[runs];
        long[] timesDelete = new long[runs];

        for (int i = 0; i < runs; i++) {
            BST bst = new BST();

            // Create sorted array
            int[] arr = new int[max];
            for (int j = 0; j < max; j++) {
                arr[j] = j + 1;
            }

            long startTime = System.currentTimeMillis();
            bst.buildBalanced(arr, 0, max - 1);
            long endTime = System.currentTimeMillis();

            if (!bst.isBST()) {
                System.out.println("Not a BST");
                return;
            }

            long startTimeDelete = System.currentTimeMillis();
            bst.removeEvens(bst.root);
            long endTimeDelete = System.currentTimeMillis();

            times[i] = endTime - startTime;
            timesDelete[i] = endTimeDelete - startTimeDelete;

            totalTime += times[i];
            totalTimeDelete += timesDelete[i];
        }

        double avgInsertTime = (double) totalTime / runs;
        double avgDeleteTime = (double) totalTimeDelete / runs;

        double stdInsert = stdDev(times, avgInsertTime);
        double stdDelete = stdDev(timesDelete, avgDeleteTime);

        System.out.println("\nResults:\n");
        System.out.printf("Average time to build balanced BST: %.2f ms (Std Dev: %.2f ms)\n", avgInsertTime, stdInsert);
        System.out.printf("Average time to delete even numbers: %.2f ms (Std Dev: %.2f ms)\n", avgDeleteTime, stdDelete);

        System.out.println("\nTimes for each run:");
        for (int i = 0; i < runs; i++) {
            System.out.printf("Run %d: Build Time = %d ms, Delete Time = %d ms\n",
                    i + 1, times[i], timesDelete[i]);
        }
    }

    public static double stdDev(long[] times, double mean) {
        double sum = 0;
        for (long time : times) {
            sum += Math.pow(time - mean, 2);
        }
        return Math.sqrt(sum / times.length);
    }
}

